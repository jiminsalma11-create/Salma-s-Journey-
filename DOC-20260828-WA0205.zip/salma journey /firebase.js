import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyCYZnLwUmb4oOS57IKgI73_hGFc_kSCBHk",
    authDomain: "salma-journey.firebaseapp.com",
    projectId: "salma-journey",
    storageBucket: "salma-journey.firebasestorage.app",
    messagingSenderId: "776204750279",
    appId: "1:776204750279:web:038389721d78b105ab1de2",
    measurementId: "G-HQP6DRCKXX"
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);

const db = getFirestore(app);

export { app, auth, db };